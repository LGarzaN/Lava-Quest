﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LavaQuestDBAPI.Model
{
    public class Examen
    {
        public int idExamen { get; set; }
        public int idUsuario { get; set; }
        public string Nombre { get; set; }

    }
}
 