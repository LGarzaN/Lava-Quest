﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LavaQuestDBAPI.Model
{
    public class Resultados
    {
        public int idUsuario { get; set; } 
        public int idExamen { get; set; }
        public float Puntaje { get; set; }  

    }
}
