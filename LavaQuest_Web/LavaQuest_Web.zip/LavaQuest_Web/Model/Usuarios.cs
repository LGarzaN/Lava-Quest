﻿namespace LavaQuest_Web.Model
{
    public class Usuarios
    {
        public string Nombre { get; set; }
        public string Correo { get; set; }
        public string Contrasena { get; set; }

    }
}
