﻿namespace LavaQuest_Web.Model
{
    public class Examen
    {
        public int idExamen { get; set; }
        public string Nombre { get; set; }
        public int idUsuario { get; set; }
    }
}
