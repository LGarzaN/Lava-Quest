﻿namespace LavaQuest_Web.Model
{
    public class Resultado
    {
        public int idResultados { get; set; }
        public int Intento { get; set; }
        public int idUsuario { get; set; }
        public int idExamen { get; set; }
        public int Puntaje { get; set; }
        public string Nombre { get; set; }

    }
}
