using LavaQuest_Web.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Utilities.Encoders;
using System.Runtime.ConstrainedExecution;
using Microsoft.AspNetCore.Http;

namespace LavaQuest_Web.Pages
{
    public class NomExamenModel : PageModel
    {
        [BindProperty]
        public string Nombre { get; set; }
        public int idEx { get; set; }
        
        public void OnGet()
        {
        }

        public IActionResult OnPost() 
        {
            string idUsuario = HttpContext.Session.GetString("idUsuario");
            int id;
            // String de conexion a la base de datos
            string cs = @"server=localhost;userid=root;password=Madrid99.;database=lavaquestbd; Allow User Variables = True;";

            using var con = new MySqlConnection(cs);
            con.Open();

            using var cmnd = new MySqlCommand();
            cmnd.Connection = con;


            cmnd.CommandText = "INSERT INTO examen(idExamen, idUsuario, Nombre) VALUES(NULL, @idUsuario, @Nombre)";
            cmnd.Parameters.AddWithValue("@Nombre", Nombre);
            cmnd.Parameters.AddWithValue("@idUsuario", idUsuario);
            cmnd.ExecuteNonQuery();

            cmnd.CommandText = "select idExamen from examen where idExamen = (select max(idExamen) from examen)";
            cmnd.ExecuteNonQuery();

            using (var reader = cmnd.ExecuteReader())
            {
                while (reader.Read())
                {
                    id = Convert.ToInt32(reader["idExamen"]);
                    idEx = id;
                    break;
                }
                
            }
            HttpContext.Session.SetInt32("idExamen", idEx);


            return RedirectToPage("/CrearExamen");


        }
    }
}
